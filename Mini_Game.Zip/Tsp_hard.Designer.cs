﻿namespace Moble
{
    partial class Tsp_hard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Tsp_hard));
            lb_timetext = new System.Windows.Forms.Label();
            panelhard1 = new System.Windows.Forms.Panel();
            pb_Tsphard16 = new System.Windows.Forms.PictureBox();
            pb_Tsphard8 = new System.Windows.Forms.PictureBox();
            pb_Tsphard12 = new System.Windows.Forms.PictureBox();
            pb_Tsphard4 = new System.Windows.Forms.PictureBox();
            pb_Tsphard15 = new System.Windows.Forms.PictureBox();
            pb_Tsphard7 = new System.Windows.Forms.PictureBox();
            pb_Tsphard11 = new System.Windows.Forms.PictureBox();
            pb_Tsphard3 = new System.Windows.Forms.PictureBox();
            pb_Tsphard14 = new System.Windows.Forms.PictureBox();
            pb_Tsphard6 = new System.Windows.Forms.PictureBox();
            pb_Tsphard10 = new System.Windows.Forms.PictureBox();
            pb_Tsphard2 = new System.Windows.Forms.PictureBox();
            pb_Tsphard13 = new System.Windows.Forms.PictureBox();
            pb_Tsphard5 = new System.Windows.Forms.PictureBox();
            pb_Tsphard9 = new System.Windows.Forms.PictureBox();
            pb_Tsphard1 = new System.Windows.Forms.PictureBox();
            lb_Tsphard_lastscore = new System.Windows.Forms.Label();
            btn_Tsphard_ok = new System.Windows.Forms.Button();
            progressbar_Tsphard = new LabelProgressBar();
            label2 = new System.Windows.Forms.Label();
            lb_TspScore = new System.Windows.Forms.Label();
            Tsphard_timer1 = new System.Windows.Forms.Timer(components);
            Tsphard_imageList = new System.Windows.Forms.ImageList(components);
            Tsphard_timer2 = new System.Windows.Forms.Timer(components);
            Tsphard_Start_Timer = new System.Windows.Forms.Timer(components);
            panelhard1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pb_Tsphard16).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pb_Tsphard8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pb_Tsphard12).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pb_Tsphard4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pb_Tsphard15).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pb_Tsphard7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pb_Tsphard11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pb_Tsphard3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pb_Tsphard14).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pb_Tsphard6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pb_Tsphard10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pb_Tsphard2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pb_Tsphard13).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pb_Tsphard5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pb_Tsphard9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pb_Tsphard1).BeginInit();
            SuspendLayout();
            // 
            // lb_timetext
            // 
            lb_timetext.AutoSize = true;
            lb_timetext.Font = new System.Drawing.Font("Cooper Black", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            lb_timetext.ForeColor = System.Drawing.Color.Black;
            lb_timetext.Location = new System.Drawing.Point(185, 551);
            lb_timetext.Name = "lb_timetext";
            lb_timetext.Size = new System.Drawing.Size(105, 110);
            lb_timetext.TabIndex = 10;
            lb_timetext.Text = "3";
            // 
            // panelhard1
            // 
            panelhard1.Controls.Add(pb_Tsphard16);
            panelhard1.Controls.Add(pb_Tsphard8);
            panelhard1.Controls.Add(pb_Tsphard12);
            panelhard1.Controls.Add(pb_Tsphard4);
            panelhard1.Controls.Add(pb_Tsphard15);
            panelhard1.Controls.Add(pb_Tsphard7);
            panelhard1.Controls.Add(pb_Tsphard11);
            panelhard1.Controls.Add(pb_Tsphard3);
            panelhard1.Controls.Add(pb_Tsphard14);
            panelhard1.Controls.Add(pb_Tsphard6);
            panelhard1.Controls.Add(pb_Tsphard10);
            panelhard1.Controls.Add(pb_Tsphard2);
            panelhard1.Controls.Add(pb_Tsphard13);
            panelhard1.Controls.Add(pb_Tsphard5);
            panelhard1.Controls.Add(pb_Tsphard9);
            panelhard1.Controls.Add(pb_Tsphard1);
            panelhard1.Location = new System.Drawing.Point(12, 135);
            panelhard1.Name = "panelhard1";
            panelhard1.Size = new System.Drawing.Size(460, 444);
            panelhard1.TabIndex = 9;
            // 
            // pb_Tsphard16
            // 
            pb_Tsphard16.Location = new System.Drawing.Point(380, 327);
            pb_Tsphard16.Name = "pb_Tsphard16";
            pb_Tsphard16.Size = new System.Drawing.Size(58, 102);
            pb_Tsphard16.TabIndex = 7;
            pb_Tsphard16.TabStop = false;
            pb_Tsphard16.Click += pb_Tsphard16_Click;
            // 
            // pb_Tsphard8
            // 
            pb_Tsphard8.Location = new System.Drawing.Point(380, 111);
            pb_Tsphard8.Name = "pb_Tsphard8";
            pb_Tsphard8.Size = new System.Drawing.Size(58, 102);
            pb_Tsphard8.TabIndex = 7;
            pb_Tsphard8.TabStop = false;
            pb_Tsphard8.Click += pb_Tsphard8_Click;
            // 
            // pb_Tsphard12
            // 
            pb_Tsphard12.Location = new System.Drawing.Point(380, 219);
            pb_Tsphard12.Name = "pb_Tsphard12";
            pb_Tsphard12.Size = new System.Drawing.Size(58, 102);
            pb_Tsphard12.TabIndex = 6;
            pb_Tsphard12.TabStop = false;
            pb_Tsphard12.Click += pb_Tsphard12_Click;
            // 
            // pb_Tsphard4
            // 
            pb_Tsphard4.Location = new System.Drawing.Point(380, 3);
            pb_Tsphard4.Name = "pb_Tsphard4";
            pb_Tsphard4.Size = new System.Drawing.Size(58, 102);
            pb_Tsphard4.TabIndex = 6;
            pb_Tsphard4.TabStop = false;
            pb_Tsphard4.Click += pb_Tsphard4_Click;
            // 
            // pb_Tsphard15
            // 
            pb_Tsphard15.Location = new System.Drawing.Point(260, 327);
            pb_Tsphard15.Name = "pb_Tsphard15";
            pb_Tsphard15.Size = new System.Drawing.Size(58, 102);
            pb_Tsphard15.TabIndex = 5;
            pb_Tsphard15.TabStop = false;
            pb_Tsphard15.Click += pb_Tsphard15_Click;
            // 
            // pb_Tsphard7
            // 
            pb_Tsphard7.Location = new System.Drawing.Point(260, 111);
            pb_Tsphard7.Name = "pb_Tsphard7";
            pb_Tsphard7.Size = new System.Drawing.Size(58, 102);
            pb_Tsphard7.TabIndex = 5;
            pb_Tsphard7.TabStop = false;
            pb_Tsphard7.Click += pb_Tsphard7_Click;
            // 
            // pb_Tsphard11
            // 
            pb_Tsphard11.Location = new System.Drawing.Point(260, 219);
            pb_Tsphard11.Name = "pb_Tsphard11";
            pb_Tsphard11.Size = new System.Drawing.Size(58, 102);
            pb_Tsphard11.TabIndex = 4;
            pb_Tsphard11.TabStop = false;
            pb_Tsphard11.Click += pb_Tsphard11_Click;
            // 
            // pb_Tsphard3
            // 
            pb_Tsphard3.Location = new System.Drawing.Point(260, 3);
            pb_Tsphard3.Name = "pb_Tsphard3";
            pb_Tsphard3.Size = new System.Drawing.Size(58, 102);
            pb_Tsphard3.TabIndex = 4;
            pb_Tsphard3.TabStop = false;
            pb_Tsphard3.Click += pb_Tsphard3_Click;
            // 
            // pb_Tsphard14
            // 
            pb_Tsphard14.Location = new System.Drawing.Point(140, 327);
            pb_Tsphard14.Name = "pb_Tsphard14";
            pb_Tsphard14.Size = new System.Drawing.Size(58, 102);
            pb_Tsphard14.TabIndex = 3;
            pb_Tsphard14.TabStop = false;
            pb_Tsphard14.Click += pb_Tsphard14_Click;
            // 
            // pb_Tsphard6
            // 
            pb_Tsphard6.Location = new System.Drawing.Point(140, 111);
            pb_Tsphard6.Name = "pb_Tsphard6";
            pb_Tsphard6.Size = new System.Drawing.Size(58, 102);
            pb_Tsphard6.TabIndex = 3;
            pb_Tsphard6.TabStop = false;
            pb_Tsphard6.Click += pb_Tsphard6_Click;
            // 
            // pb_Tsphard10
            // 
            pb_Tsphard10.Location = new System.Drawing.Point(140, 219);
            pb_Tsphard10.Name = "pb_Tsphard10";
            pb_Tsphard10.Size = new System.Drawing.Size(58, 102);
            pb_Tsphard10.TabIndex = 2;
            pb_Tsphard10.TabStop = false;
            pb_Tsphard10.Click += pb_Tsphard10_Click;
            // 
            // pb_Tsphard2
            // 
            pb_Tsphard2.Location = new System.Drawing.Point(140, 3);
            pb_Tsphard2.Name = "pb_Tsphard2";
            pb_Tsphard2.Size = new System.Drawing.Size(58, 102);
            pb_Tsphard2.TabIndex = 2;
            pb_Tsphard2.TabStop = false;
            pb_Tsphard2.Click += pb_Tsphard2_Click;
            // 
            // pb_Tsphard13
            // 
            pb_Tsphard13.Location = new System.Drawing.Point(20, 327);
            pb_Tsphard13.Name = "pb_Tsphard13";
            pb_Tsphard13.Size = new System.Drawing.Size(58, 102);
            pb_Tsphard13.TabIndex = 1;
            pb_Tsphard13.TabStop = false;
            pb_Tsphard13.Click += pb_Tsphard13_Click;
            // 
            // pb_Tsphard5
            // 
            pb_Tsphard5.Location = new System.Drawing.Point(20, 111);
            pb_Tsphard5.Name = "pb_Tsphard5";
            pb_Tsphard5.Size = new System.Drawing.Size(58, 102);
            pb_Tsphard5.TabIndex = 1;
            pb_Tsphard5.TabStop = false;
            pb_Tsphard5.Click += pb_Tsphard5_Click;
            // 
            // pb_Tsphard9
            // 
            pb_Tsphard9.Location = new System.Drawing.Point(20, 219);
            pb_Tsphard9.Name = "pb_Tsphard9";
            pb_Tsphard9.Size = new System.Drawing.Size(58, 102);
            pb_Tsphard9.TabIndex = 0;
            pb_Tsphard9.TabStop = false;
            pb_Tsphard9.Click += pb_Tsphard9_Click;
            // 
            // pb_Tsphard1
            // 
            pb_Tsphard1.Location = new System.Drawing.Point(20, 3);
            pb_Tsphard1.Name = "pb_Tsphard1";
            pb_Tsphard1.Size = new System.Drawing.Size(58, 102);
            pb_Tsphard1.TabIndex = 0;
            pb_Tsphard1.TabStop = false;
            pb_Tsphard1.Click += pb_Tsphard1_Click;
            // 
            // lb_Tsphard_lastscore
            // 
            lb_Tsphard_lastscore.AutoSize = true;
            lb_Tsphard_lastscore.Font = new System.Drawing.Font("Cooper Black", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            lb_Tsphard_lastscore.ForeColor = System.Drawing.Color.White;
            lb_Tsphard_lastscore.Location = new System.Drawing.Point(60, 170);
            lb_Tsphard_lastscore.Name = "lb_Tsphard_lastscore";
            lb_Tsphard_lastscore.Size = new System.Drawing.Size(369, 74);
            lb_Tsphard_lastscore.TabIndex = 9;
            lb_Tsphard_lastscore.Text = "score : 100";
            // 
            // btn_Tsphard_ok
            // 
            btn_Tsphard_ok.BackColor = System.Drawing.Color.White;
            btn_Tsphard_ok.Font = new System.Drawing.Font("휴먼둥근헤드라인", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btn_Tsphard_ok.Location = new System.Drawing.Point(160, 335);
            btn_Tsphard_ok.Name = "btn_Tsphard_ok";
            btn_Tsphard_ok.Size = new System.Drawing.Size(164, 87);
            btn_Tsphard_ok.TabIndex = 8;
            btn_Tsphard_ok.Text = "확인";
            btn_Tsphard_ok.UseVisualStyleBackColor = false;
            btn_Tsphard_ok.Click += btn_Tsphard_ok_Click;
            // 
            // progressbar_Tsphard
            // 
            progressbar_Tsphard.CustomText = "progressbar_hard";
            progressbar_Tsphard.Location = new System.Drawing.Point(12, 12);
            progressbar_Tsphard.Maximum = 300;
            progressbar_Tsphard.Name = "progressbar_Tsphard";
            progressbar_Tsphard.ProgressColor = System.Drawing.Color.White;
            progressbar_Tsphard.Size = new System.Drawing.Size(460, 23);
            progressbar_Tsphard.TabIndex = 8;
            progressbar_Tsphard.TextColor = System.Drawing.Color.RoyalBlue;
            progressbar_Tsphard.TextFont = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            progressbar_Tsphard.Value = 300;
            progressbar_Tsphard.VisualMode = ProgressBarDisplayMode.CustomText;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label2.ForeColor = System.Drawing.Color.White;
            label2.Location = new System.Drawing.Point(225, 115);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(52, 19);
            label2.TabIndex = 7;
            label2.Text = "score";
            // 
            // lb_TspScore
            // 
            lb_TspScore.AutoSize = true;
            lb_TspScore.Font = new System.Drawing.Font("Cooper Black", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            lb_TspScore.ForeColor = System.Drawing.Color.White;
            lb_TspScore.Location = new System.Drawing.Point(175, 50);
            lb_TspScore.Name = "lb_TspScore";
            lb_TspScore.Size = new System.Drawing.Size(146, 74);
            lb_TspScore.TabIndex = 6;
            lb_TspScore.Text = "200";
            // 
            // Tsphard_timer1
            // 
            Tsphard_timer1.Tick += Tsphard_timer1_Tick;
            // 
            // Tsphard_imageList
            // 
            Tsphard_imageList.ColorDepth = System.Windows.Forms.ColorDepth.Depth24Bit;
            Tsphard_imageList.ImageStream = (System.Windows.Forms.ImageListStreamer)resources.GetObject("Tsphard_imageList.ImageStream");
            Tsphard_imageList.TransparentColor = System.Drawing.Color.Transparent;
            Tsphard_imageList.Images.SetKeyName(0, "뒷면.jpg");
            Tsphard_imageList.Images.SetKeyName(1, "1만.jpg");
            Tsphard_imageList.Images.SetKeyName(2, "1삭.jpg");
            Tsphard_imageList.Images.SetKeyName(3, "1통.jpg");
            Tsphard_imageList.Images.SetKeyName(4, "5만.jpg");
            Tsphard_imageList.Images.SetKeyName(5, "5삭.jpg");
            Tsphard_imageList.Images.SetKeyName(6, "5통.jpg");
            Tsphard_imageList.Images.SetKeyName(7, "8만.jpg");
            Tsphard_imageList.Images.SetKeyName(8, "8삭.jpg");
            Tsphard_imageList.Images.SetKeyName(9, "8통.jpg");
            Tsphard_imageList.Images.SetKeyName(10, "9만.jpg");
            Tsphard_imageList.Images.SetKeyName(11, "9삭.jpg");
            Tsphard_imageList.Images.SetKeyName(12, "북.jpg");
            Tsphard_imageList.Images.SetKeyName(13, "9통.jpg");
            Tsphard_imageList.Images.SetKeyName(14, "남.jpg");
            Tsphard_imageList.Images.SetKeyName(15, "동.jpg");
            Tsphard_imageList.Images.SetKeyName(16, "중.jpg");
            Tsphard_imageList.Images.SetKeyName(17, "발.jpg");
            Tsphard_imageList.Images.SetKeyName(18, "백.jpg");
            Tsphard_imageList.Images.SetKeyName(19, "서.jpg");
            Tsphard_imageList.Images.SetKeyName(20, "3만.jpg");
            Tsphard_imageList.Images.SetKeyName(21, "3삭.jpg");
            Tsphard_imageList.Images.SetKeyName(22, "3통.jpg");
            Tsphard_imageList.Images.SetKeyName(23, "북2.jpg");
            Tsphard_imageList.Images.SetKeyName(24, "중2.jpg");
            // 
            // Tsphard_timer2
            // 
            Tsphard_timer2.Tick += Tsphard_timer2_Tick;
            // 
            // Tsphard_Start_Timer
            // 
            Tsphard_Start_Timer.Interval = 1000;
            Tsphard_Start_Timer.Tick += Tsphard_Start_Timer_Tick;
            // 
            // Tsp_hard
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            BackColor = System.Drawing.Color.RoyalBlue;
            ClientSize = new System.Drawing.Size(484, 661);
            Controls.Add(btn_Tsphard_ok);
            Controls.Add(lb_Tsphard_lastscore);
            Controls.Add(panelhard1);
            Controls.Add(progressbar_Tsphard);
            Controls.Add(lb_timetext);
            Controls.Add(label2);
            Controls.Add(lb_TspScore);
            Name = "Tsp_hard";
            Text = "같은그림찾기 게임 하드모드";
            panelhard1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pb_Tsphard16).EndInit();
            ((System.ComponentModel.ISupportInitialize)pb_Tsphard8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pb_Tsphard12).EndInit();
            ((System.ComponentModel.ISupportInitialize)pb_Tsphard4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pb_Tsphard15).EndInit();
            ((System.ComponentModel.ISupportInitialize)pb_Tsphard7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pb_Tsphard11).EndInit();
            ((System.ComponentModel.ISupportInitialize)pb_Tsphard3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pb_Tsphard14).EndInit();
            ((System.ComponentModel.ISupportInitialize)pb_Tsphard6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pb_Tsphard10).EndInit();
            ((System.ComponentModel.ISupportInitialize)pb_Tsphard2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pb_Tsphard13).EndInit();
            ((System.ComponentModel.ISupportInitialize)pb_Tsphard5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pb_Tsphard9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pb_Tsphard1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label lb_timetext;
        private System.Windows.Forms.Panel panelhard1;
        private System.Windows.Forms.PictureBox pb_Tsphard8;
        private System.Windows.Forms.PictureBox pb_Tsphard4;
        private System.Windows.Forms.PictureBox pb_Tsphard7;
        private System.Windows.Forms.PictureBox pb_Tsphard3;
        private System.Windows.Forms.PictureBox pb_Tsphard6;
        private System.Windows.Forms.PictureBox pb_Tsphard2;
        private System.Windows.Forms.PictureBox pb_Tsphard5;
        private System.Windows.Forms.PictureBox pb_Tsphard1;
        private LabelProgressBar progressbar_Tsphard;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lb_TspScore;
        private System.Windows.Forms.PictureBox pb_Tsphard16;
        private System.Windows.Forms.PictureBox pb_Tsphard12;
        private System.Windows.Forms.PictureBox pb_Tsphard15;
        private System.Windows.Forms.PictureBox pb_Tsphard11;
        private System.Windows.Forms.PictureBox pb_Tsphard14;
        private System.Windows.Forms.PictureBox pb_Tsphard10;
        private System.Windows.Forms.PictureBox pb_Tsphard13;
        private System.Windows.Forms.PictureBox pb_Tsphard9;
        private System.Windows.Forms.Timer Tsphard_timer1;
        private System.Windows.Forms.ImageList Tsphard_imageList;
        private System.Windows.Forms.Timer Tsphard_timer2;
        private System.Windows.Forms.Timer Tsphard_Start_Timer;
        private System.Windows.Forms.Label lb_Tsphard_lastscore;
        private System.Windows.Forms.Button btn_Tsphard_ok;
    }
}