﻿namespace Gandi
{
    partial class NumGame
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NumGame));
            pictureBox1 = new System.Windows.Forms.PictureBox();
            label1 = new System.Windows.Forms.Label();
            pictureBox2 = new System.Windows.Forms.PictureBox();
            pictureBox3 = new System.Windows.Forms.PictureBox();
            pictureBox4 = new System.Windows.Forms.PictureBox();
            pictureBox8 = new System.Windows.Forms.PictureBox();
            pictureBox7 = new System.Windows.Forms.PictureBox();
            pictureBox6 = new System.Windows.Forms.PictureBox();
            label5 = new System.Windows.Forms.Label();
            pictureBox5 = new System.Windows.Forms.PictureBox();
            pictureBox12 = new System.Windows.Forms.PictureBox();
            pictureBox11 = new System.Windows.Forms.PictureBox();
            pictureBox10 = new System.Windows.Forms.PictureBox();
            label9 = new System.Windows.Forms.Label();
            pictureBox9 = new System.Windows.Forms.PictureBox();
            pictureBox16 = new System.Windows.Forms.PictureBox();
            pictureBox15 = new System.Windows.Forms.PictureBox();
            pictureBox14 = new System.Windows.Forms.PictureBox();
            label13 = new System.Windows.Forms.Label();
            pictureBox13 = new System.Windows.Forms.PictureBox();
            label2 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            label6 = new System.Windows.Forms.Label();
            label7 = new System.Windows.Forms.Label();
            label8 = new System.Windows.Forms.Label();
            label10 = new System.Windows.Forms.Label();
            label11 = new System.Windows.Forms.Label();
            label12 = new System.Windows.Forms.Label();
            label14 = new System.Windows.Forms.Label();
            label15 = new System.Windows.Forms.Label();
            label16 = new System.Windows.Forms.Label();
            proBar = new Moble.LabelProgressBar();
            score = new System.Windows.Forms.Label();
            picNo1 = new System.Windows.Forms.PictureBox();
            label17 = new System.Windows.Forms.Label();
            timer1 = new System.Windows.Forms.Timer(components);
            lbEndScore = new System.Windows.Forms.Label();
            picNo2 = new System.Windows.Forms.PictureBox();
            picNo3 = new System.Windows.Forms.PictureBox();
            picNo4 = new System.Windows.Forms.PictureBox();
            picNo5 = new System.Windows.Forms.PictureBox();
            picNo6 = new System.Windows.Forms.PictureBox();
            picNo7 = new System.Windows.Forms.PictureBox();
            picNo8 = new System.Windows.Forms.PictureBox();
            picNo9 = new System.Windows.Forms.PictureBox();
            picNo10 = new System.Windows.Forms.PictureBox();
            picNo11 = new System.Windows.Forms.PictureBox();
            picNo12 = new System.Windows.Forms.PictureBox();
            picNo13 = new System.Windows.Forms.PictureBox();
            picNo14 = new System.Windows.Forms.PictureBox();
            picNo15 = new System.Windows.Forms.PictureBox();
            picNo16 = new System.Windows.Forms.PictureBox();
            lbcnt = new System.Windows.Forms.Label();
            timer2 = new System.Windows.Forms.Timer(components);
            button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox16).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox15).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox14).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).BeginInit();
            ((System.ComponentModel.ISupportInitialize)picNo1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)picNo2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)picNo3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)picNo4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)picNo5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)picNo6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)picNo7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)picNo8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)picNo9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)picNo10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)picNo11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)picNo12).BeginInit();
            ((System.ComponentModel.ISupportInitialize)picNo13).BeginInit();
            ((System.ComponentModel.ISupportInitialize)picNo14).BeginInit();
            ((System.ComponentModel.ISupportInitialize)picNo15).BeginInit();
            ((System.ComponentModel.ISupportInitialize)picNo16).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (System.Drawing.Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new System.Drawing.Point(12, 173);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new System.Drawing.Size(109, 108);
            pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = System.Drawing.Color.MintCream;
            label1.Font = new System.Drawing.Font("Cooper Black", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label1.Location = new System.Drawing.Point(39, 202);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(53, 55);
            label1.TabIndex = 1;
            label1.Text = "1";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (System.Drawing.Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new System.Drawing.Point(129, 173);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new System.Drawing.Size(109, 108);
            pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 2;
            pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (System.Drawing.Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new System.Drawing.Point(246, 173);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new System.Drawing.Size(109, 108);
            pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 3;
            pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (System.Drawing.Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new System.Drawing.Point(363, 173);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new System.Drawing.Size(109, 108);
            pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 4;
            pictureBox4.TabStop = false;
            // 
            // pictureBox8
            // 
            pictureBox8.Image = (System.Drawing.Image)resources.GetObject("pictureBox8.Image");
            pictureBox8.Location = new System.Drawing.Point(363, 287);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new System.Drawing.Size(109, 108);
            pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox8.TabIndex = 9;
            pictureBox8.TabStop = false;
            // 
            // pictureBox7
            // 
            pictureBox7.Image = (System.Drawing.Image)resources.GetObject("pictureBox7.Image");
            pictureBox7.Location = new System.Drawing.Point(246, 287);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new System.Drawing.Size(109, 108);
            pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox7.TabIndex = 8;
            pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = (System.Drawing.Image)resources.GetObject("pictureBox6.Image");
            pictureBox6.Location = new System.Drawing.Point(129, 287);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new System.Drawing.Size(109, 108);
            pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox6.TabIndex = 7;
            pictureBox6.TabStop = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = System.Drawing.Color.MintCream;
            label5.Font = new System.Drawing.Font("Cooper Black", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label5.Location = new System.Drawing.Point(41, 316);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(53, 55);
            label5.TabIndex = 6;
            label5.Text = "5";
            // 
            // pictureBox5
            // 
            pictureBox5.Image = (System.Drawing.Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new System.Drawing.Point(12, 287);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new System.Drawing.Size(109, 108);
            pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox5.TabIndex = 5;
            pictureBox5.TabStop = false;
            // 
            // pictureBox12
            // 
            pictureBox12.Image = (System.Drawing.Image)resources.GetObject("pictureBox12.Image");
            pictureBox12.Location = new System.Drawing.Point(363, 401);
            pictureBox12.Name = "pictureBox12";
            pictureBox12.Size = new System.Drawing.Size(109, 108);
            pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox12.TabIndex = 14;
            pictureBox12.TabStop = false;
            // 
            // pictureBox11
            // 
            pictureBox11.Image = (System.Drawing.Image)resources.GetObject("pictureBox11.Image");
            pictureBox11.Location = new System.Drawing.Point(246, 401);
            pictureBox11.Name = "pictureBox11";
            pictureBox11.Size = new System.Drawing.Size(109, 108);
            pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox11.TabIndex = 13;
            pictureBox11.TabStop = false;
            // 
            // pictureBox10
            // 
            pictureBox10.Image = (System.Drawing.Image)resources.GetObject("pictureBox10.Image");
            pictureBox10.Location = new System.Drawing.Point(129, 401);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new System.Drawing.Size(109, 108);
            pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox10.TabIndex = 12;
            pictureBox10.TabStop = false;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = System.Drawing.Color.MintCream;
            label9.Font = new System.Drawing.Font("Cooper Black", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label9.Location = new System.Drawing.Point(39, 430);
            label9.Name = "label9";
            label9.Size = new System.Drawing.Size(53, 55);
            label9.TabIndex = 11;
            label9.Text = "9";
            // 
            // pictureBox9
            // 
            pictureBox9.Image = (System.Drawing.Image)resources.GetObject("pictureBox9.Image");
            pictureBox9.Location = new System.Drawing.Point(12, 401);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new System.Drawing.Size(109, 108);
            pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox9.TabIndex = 10;
            pictureBox9.TabStop = false;
            // 
            // pictureBox16
            // 
            pictureBox16.Image = (System.Drawing.Image)resources.GetObject("pictureBox16.Image");
            pictureBox16.Location = new System.Drawing.Point(363, 515);
            pictureBox16.Name = "pictureBox16";
            pictureBox16.Size = new System.Drawing.Size(109, 108);
            pictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox16.TabIndex = 19;
            pictureBox16.TabStop = false;
            // 
            // pictureBox15
            // 
            pictureBox15.Image = (System.Drawing.Image)resources.GetObject("pictureBox15.Image");
            pictureBox15.Location = new System.Drawing.Point(246, 515);
            pictureBox15.Name = "pictureBox15";
            pictureBox15.Size = new System.Drawing.Size(109, 108);
            pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox15.TabIndex = 18;
            pictureBox15.TabStop = false;
            // 
            // pictureBox14
            // 
            pictureBox14.Image = (System.Drawing.Image)resources.GetObject("pictureBox14.Image");
            pictureBox14.Location = new System.Drawing.Point(129, 515);
            pictureBox14.Name = "pictureBox14";
            pictureBox14.Size = new System.Drawing.Size(109, 108);
            pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox14.TabIndex = 17;
            pictureBox14.TabStop = false;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.BackColor = System.Drawing.Color.MintCream;
            label13.Font = new System.Drawing.Font("Cooper Black", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label13.Location = new System.Drawing.Point(28, 536);
            label13.Name = "label13";
            label13.Size = new System.Drawing.Size(82, 55);
            label13.TabIndex = 16;
            label13.Text = "13";
            // 
            // pictureBox13
            // 
            pictureBox13.Image = (System.Drawing.Image)resources.GetObject("pictureBox13.Image");
            pictureBox13.Location = new System.Drawing.Point(12, 515);
            pictureBox13.Name = "pictureBox13";
            pictureBox13.Size = new System.Drawing.Size(109, 108);
            pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox13.TabIndex = 15;
            pictureBox13.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = System.Drawing.Color.MintCream;
            label2.Font = new System.Drawing.Font("Cooper Black", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label2.Location = new System.Drawing.Point(156, 201);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(53, 55);
            label2.TabIndex = 20;
            label2.Text = "2";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = System.Drawing.Color.MintCream;
            label3.Font = new System.Drawing.Font("Cooper Black", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label3.Location = new System.Drawing.Point(272, 202);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(53, 55);
            label3.TabIndex = 21;
            label3.Text = "3";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = System.Drawing.Color.MintCream;
            label4.Font = new System.Drawing.Font("Cooper Black", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label4.Location = new System.Drawing.Point(389, 201);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(53, 55);
            label4.TabIndex = 22;
            label4.Text = "4";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = System.Drawing.Color.MintCream;
            label6.Font = new System.Drawing.Font("Cooper Black", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label6.Location = new System.Drawing.Point(157, 314);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(53, 55);
            label6.TabIndex = 23;
            label6.Text = "6";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = System.Drawing.Color.MintCream;
            label7.Font = new System.Drawing.Font("Cooper Black", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label7.Location = new System.Drawing.Point(274, 313);
            label7.Name = "label7";
            label7.Size = new System.Drawing.Size(53, 55);
            label7.TabIndex = 24;
            label7.Text = "7";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = System.Drawing.Color.MintCream;
            label8.Font = new System.Drawing.Font("Cooper Black", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label8.Location = new System.Drawing.Point(390, 313);
            label8.Name = "label8";
            label8.Size = new System.Drawing.Size(53, 55);
            label8.TabIndex = 25;
            label8.Text = "8";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = System.Drawing.Color.MintCream;
            label10.Font = new System.Drawing.Font("Cooper Black", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label10.Location = new System.Drawing.Point(145, 426);
            label10.Name = "label10";
            label10.Size = new System.Drawing.Size(82, 55);
            label10.TabIndex = 26;
            label10.Text = "10";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.BackColor = System.Drawing.Color.MintCream;
            label11.Font = new System.Drawing.Font("Cooper Black", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label11.Location = new System.Drawing.Point(260, 425);
            label11.Name = "label11";
            label11.Size = new System.Drawing.Size(82, 55);
            label11.TabIndex = 27;
            label11.Text = "11";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.BackColor = System.Drawing.Color.MintCream;
            label12.Font = new System.Drawing.Font("Cooper Black", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label12.Location = new System.Drawing.Point(377, 424);
            label12.Name = "label12";
            label12.Size = new System.Drawing.Size(82, 55);
            label12.TabIndex = 28;
            label12.Text = "12";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.BackColor = System.Drawing.Color.MintCream;
            label14.Font = new System.Drawing.Font("Cooper Black", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label14.Location = new System.Drawing.Point(141, 536);
            label14.Name = "label14";
            label14.Size = new System.Drawing.Size(82, 55);
            label14.TabIndex = 29;
            label14.Text = "14";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.BackColor = System.Drawing.Color.MintCream;
            label15.Font = new System.Drawing.Font("Cooper Black", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label15.Location = new System.Drawing.Point(260, 538);
            label15.Name = "label15";
            label15.Size = new System.Drawing.Size(82, 55);
            label15.TabIndex = 30;
            label15.Text = "15";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.BackColor = System.Drawing.Color.MintCream;
            label16.Font = new System.Drawing.Font("Cooper Black", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label16.Location = new System.Drawing.Point(376, 539);
            label16.Name = "label16";
            label16.Size = new System.Drawing.Size(82, 55);
            label16.TabIndex = 31;
            label16.Text = "16";
            // 
            // proBar
            // 
            proBar.BackColor = System.Drawing.Color.RoyalBlue;
            proBar.CustomText = "";
            proBar.Location = new System.Drawing.Point(12, 12);
            proBar.Maximum = 200;
            proBar.Name = "proBar";
            proBar.ProgressColor = System.Drawing.Color.Aqua;
            proBar.Size = new System.Drawing.Size(460, 30);
            proBar.TabIndex = 32;
            proBar.TextColor = System.Drawing.Color.RoyalBlue;
            proBar.TextFont = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            proBar.VisualMode = Moble.ProgressBarDisplayMode.CustomText;
            // 
            // score
            // 
            score.AutoSize = true;
            score.Font = new System.Drawing.Font("Cooper Black", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            score.ForeColor = System.Drawing.Color.White;
            score.Location = new System.Drawing.Point(170, 45);
            score.Name = "score";
            score.Size = new System.Drawing.Size(146, 74);
            score.TabIndex = 33;
            score.Text = "100";
            // 
            // picNo1
            // 
            picNo1.Image = (System.Drawing.Image)resources.GetObject("picNo1.Image");
            picNo1.Location = new System.Drawing.Point(246, 401);
            picNo1.Name = "picNo1";
            picNo1.Size = new System.Drawing.Size(109, 108);
            picNo1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            picNo1.TabIndex = 34;
            picNo1.TabStop = false;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label17.ForeColor = System.Drawing.Color.White;
            label17.Location = new System.Drawing.Point(217, 114);
            label17.Name = "label17";
            label17.Size = new System.Drawing.Size(52, 19);
            label17.TabIndex = 35;
            label17.Text = "score";
            // 
            // timer1
            // 
            timer1.Tick += timer1_Tick;
            // 
            // lbEndScore
            // 
            lbEndScore.AutoSize = true;
            lbEndScore.BackColor = System.Drawing.Color.RoyalBlue;
            lbEndScore.Font = new System.Drawing.Font("Cooper Black", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            lbEndScore.ForeColor = System.Drawing.Color.White;
            lbEndScore.Location = new System.Drawing.Point(60, 170);
            lbEndScore.Name = "lbEndScore";
            lbEndScore.Size = new System.Drawing.Size(369, 74);
            lbEndScore.TabIndex = 36;
            lbEndScore.Text = "score : 100";
            // 
            // picNo2
            // 
            picNo2.Image = (System.Drawing.Image)resources.GetObject("picNo2.Image");
            picNo2.Location = new System.Drawing.Point(363, 287);
            picNo2.Name = "picNo2";
            picNo2.Size = new System.Drawing.Size(109, 108);
            picNo2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            picNo2.TabIndex = 37;
            picNo2.TabStop = false;
            // 
            // picNo3
            // 
            picNo3.Image = (System.Drawing.Image)resources.GetObject("picNo3.Image");
            picNo3.Location = new System.Drawing.Point(361, 170);
            picNo3.Name = "picNo3";
            picNo3.Size = new System.Drawing.Size(109, 108);
            picNo3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            picNo3.TabIndex = 38;
            picNo3.TabStop = false;
            // 
            // picNo4
            // 
            picNo4.Image = (System.Drawing.Image)resources.GetObject("picNo4.Image");
            picNo4.Location = new System.Drawing.Point(12, 170);
            picNo4.Name = "picNo4";
            picNo4.Size = new System.Drawing.Size(109, 108);
            picNo4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            picNo4.TabIndex = 39;
            picNo4.TabStop = false;
            // 
            // picNo5
            // 
            picNo5.Image = (System.Drawing.Image)resources.GetObject("picNo5.Image");
            picNo5.Location = new System.Drawing.Point(127, 173);
            picNo5.Name = "picNo5";
            picNo5.Size = new System.Drawing.Size(109, 108);
            picNo5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            picNo5.TabIndex = 40;
            picNo5.TabStop = false;
            // 
            // picNo6
            // 
            picNo6.Image = (System.Drawing.Image)resources.GetObject("picNo6.Image");
            picNo6.Location = new System.Drawing.Point(127, 401);
            picNo6.Name = "picNo6";
            picNo6.Size = new System.Drawing.Size(109, 108);
            picNo6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            picNo6.TabIndex = 41;
            picNo6.TabStop = false;
            // 
            // picNo7
            // 
            picNo7.Image = (System.Drawing.Image)resources.GetObject("picNo7.Image");
            picNo7.Location = new System.Drawing.Point(361, 401);
            picNo7.Name = "picNo7";
            picNo7.Size = new System.Drawing.Size(109, 108);
            picNo7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            picNo7.TabIndex = 42;
            picNo7.TabStop = false;
            // 
            // picNo8
            // 
            picNo8.Image = (System.Drawing.Image)resources.GetObject("picNo8.Image");
            picNo8.Location = new System.Drawing.Point(248, 173);
            picNo8.Name = "picNo8";
            picNo8.Size = new System.Drawing.Size(109, 108);
            picNo8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            picNo8.TabIndex = 43;
            picNo8.TabStop = false;
            // 
            // picNo9
            // 
            picNo9.Image = (System.Drawing.Image)resources.GetObject("picNo9.Image");
            picNo9.Location = new System.Drawing.Point(12, 515);
            picNo9.Name = "picNo9";
            picNo9.Size = new System.Drawing.Size(109, 108);
            picNo9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            picNo9.TabIndex = 44;
            picNo9.TabStop = false;
            // 
            // picNo10
            // 
            picNo10.Image = (System.Drawing.Image)resources.GetObject("picNo10.Image");
            picNo10.Location = new System.Drawing.Point(246, 515);
            picNo10.Name = "picNo10";
            picNo10.Size = new System.Drawing.Size(109, 108);
            picNo10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            picNo10.TabIndex = 45;
            picNo10.TabStop = false;
            // 
            // picNo11
            // 
            picNo11.Image = (System.Drawing.Image)resources.GetObject("picNo11.Image");
            picNo11.Location = new System.Drawing.Point(361, 515);
            picNo11.Name = "picNo11";
            picNo11.Size = new System.Drawing.Size(109, 108);
            picNo11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            picNo11.TabIndex = 46;
            picNo11.TabStop = false;
            // 
            // picNo12
            // 
            picNo12.Image = (System.Drawing.Image)resources.GetObject("picNo12.Image");
            picNo12.Location = new System.Drawing.Point(127, 515);
            picNo12.Name = "picNo12";
            picNo12.Size = new System.Drawing.Size(109, 108);
            picNo12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            picNo12.TabIndex = 47;
            picNo12.TabStop = false;
            // 
            // picNo13
            // 
            picNo13.Image = (System.Drawing.Image)resources.GetObject("picNo13.Image");
            picNo13.Location = new System.Drawing.Point(14, 401);
            picNo13.Name = "picNo13";
            picNo13.Size = new System.Drawing.Size(109, 108);
            picNo13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            picNo13.TabIndex = 48;
            picNo13.TabStop = false;
            // 
            // picNo14
            // 
            picNo14.Image = (System.Drawing.Image)resources.GetObject("picNo14.Image");
            picNo14.Location = new System.Drawing.Point(12, 287);
            picNo14.Name = "picNo14";
            picNo14.Size = new System.Drawing.Size(109, 108);
            picNo14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            picNo14.TabIndex = 49;
            picNo14.TabStop = false;
            // 
            // picNo15
            // 
            picNo15.Image = (System.Drawing.Image)resources.GetObject("picNo15.Image");
            picNo15.Location = new System.Drawing.Point(127, 287);
            picNo15.Name = "picNo15";
            picNo15.Size = new System.Drawing.Size(109, 108);
            picNo15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            picNo15.TabIndex = 50;
            picNo15.TabStop = false;
            // 
            // picNo16
            // 
            picNo16.Image = (System.Drawing.Image)resources.GetObject("picNo16.Image");
            picNo16.Location = new System.Drawing.Point(244, 287);
            picNo16.Name = "picNo16";
            picNo16.Size = new System.Drawing.Size(109, 108);
            picNo16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            picNo16.TabIndex = 51;
            picNo16.TabStop = false;
            // 
            // lbcnt
            // 
            lbcnt.AutoSize = true;
            lbcnt.Font = new System.Drawing.Font("휴먼둥근헤드라인", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            lbcnt.Location = new System.Drawing.Point(190, 353);
            lbcnt.Name = "lbcnt";
            lbcnt.Size = new System.Drawing.Size(112, 101);
            lbcnt.TabIndex = 52;
            lbcnt.Text = "3";
            // 
            // timer2
            // 
            timer2.Tick += timer2_Tick;
            // 
            // button1
            // 
            button1.BackColor = System.Drawing.Color.White;
            button1.Font = new System.Drawing.Font("휴먼둥근헤드라인", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            button1.ForeColor = System.Drawing.Color.Black;
            button1.Location = new System.Drawing.Point(160, 350);
            button1.Name = "button1";
            button1.Size = new System.Drawing.Size(164, 87);
            button1.TabIndex = 53;
            button1.Text = "확인";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // NumGame
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            BackColor = System.Drawing.Color.RoyalBlue;
            ClientSize = new System.Drawing.Size(484, 661);
            Controls.Add(button1);
            Controls.Add(lbcnt);
            Controls.Add(lbEndScore);
            Controls.Add(picNo16);
            Controls.Add(picNo15);
            Controls.Add(picNo14);
            Controls.Add(picNo13);
            Controls.Add(picNo12);
            Controls.Add(picNo11);
            Controls.Add(picNo10);
            Controls.Add(picNo9);
            Controls.Add(picNo8);
            Controls.Add(picNo7);
            Controls.Add(picNo6);
            Controls.Add(picNo5);
            Controls.Add(picNo4);
            Controls.Add(picNo3);
            Controls.Add(picNo2);
            Controls.Add(label17);
            Controls.Add(picNo1);
            Controls.Add(score);
            Controls.Add(proBar);
            Controls.Add(label16);
            Controls.Add(label15);
            Controls.Add(label14);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(pictureBox16);
            Controls.Add(pictureBox15);
            Controls.Add(pictureBox14);
            Controls.Add(label13);
            Controls.Add(pictureBox13);
            Controls.Add(pictureBox12);
            Controls.Add(pictureBox11);
            Controls.Add(pictureBox10);
            Controls.Add(label9);
            Controls.Add(pictureBox9);
            Controls.Add(pictureBox8);
            Controls.Add(pictureBox7);
            Controls.Add(pictureBox6);
            Controls.Add(label5);
            Controls.Add(pictureBox5);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            Controls.Add(label1);
            Controls.Add(pictureBox1);
            Name = "NumGame";
            Text = "순서대로 게임";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox16).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox15).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox14).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).EndInit();
            ((System.ComponentModel.ISupportInitialize)picNo1).EndInit();
            ((System.ComponentModel.ISupportInitialize)picNo2).EndInit();
            ((System.ComponentModel.ISupportInitialize)picNo3).EndInit();
            ((System.ComponentModel.ISupportInitialize)picNo4).EndInit();
            ((System.ComponentModel.ISupportInitialize)picNo5).EndInit();
            ((System.ComponentModel.ISupportInitialize)picNo6).EndInit();
            ((System.ComponentModel.ISupportInitialize)picNo7).EndInit();
            ((System.ComponentModel.ISupportInitialize)picNo8).EndInit();
            ((System.ComponentModel.ISupportInitialize)picNo9).EndInit();
            ((System.ComponentModel.ISupportInitialize)picNo10).EndInit();
            ((System.ComponentModel.ISupportInitialize)picNo11).EndInit();
            ((System.ComponentModel.ISupportInitialize)picNo12).EndInit();
            ((System.ComponentModel.ISupportInitialize)picNo13).EndInit();
            ((System.ComponentModel.ISupportInitialize)picNo14).EndInit();
            ((System.ComponentModel.ISupportInitialize)picNo15).EndInit();
            ((System.ComponentModel.ISupportInitialize)picNo16).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label score;
        private System.Windows.Forms.PictureBox picNo1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.PictureBox picNo2;
        private System.Windows.Forms.PictureBox picNo3;
        private System.Windows.Forms.PictureBox picNo4;
        private System.Windows.Forms.PictureBox picNo5;
        private System.Windows.Forms.PictureBox picNo6;
        private System.Windows.Forms.PictureBox picNo7;
        private System.Windows.Forms.PictureBox picNo8;
        private System.Windows.Forms.PictureBox picNo9;
        private System.Windows.Forms.PictureBox picNo10;
        private System.Windows.Forms.PictureBox picNo11;
        private System.Windows.Forms.PictureBox picNo12;
        private System.Windows.Forms.PictureBox picNo13;
        private System.Windows.Forms.PictureBox picNo14;
        private System.Windows.Forms.PictureBox picNo15;
        private System.Windows.Forms.PictureBox picNo16;
        private System.Windows.Forms.Label lbcnt;
        private System.Windows.Forms.Timer timer2;
        public System.Windows.Forms.Timer timer1;
        public System.Windows.Forms.Label lbEndScore;
        public Moble.LabelProgressBar proBar;
        private System.Windows.Forms.Button button1;
    }
}
